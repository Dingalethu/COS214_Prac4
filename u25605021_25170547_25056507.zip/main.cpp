#include <iostream>
#include <string>
#include <vector>
#include "FireDepartment.h"
#include "PoliceDepartment.h"
#include "MedicalDepartment.h"
#include "EmergencyTask.h"
#include "PriorityDecorator.h"
#include "SafetyCheckDecorator.h"
#include "ActiveTaskIterator.h"
#include "CompleteDfsIterator.h"
#include "AlertState.h"
#include "ResponseState.h"
#include "RecoveryState.h"

using namespace std;

// Helper: Print iterator contents using the iterator interface
void printIterator(WorkIterator* it, const string& title){
    cout << "\n=== " << title << " ===" << endl;
    int count = 0;
    it->first();
    while(!it->isDone()){
        Component* comp = it->currentItem();
        count++;
        cout << count << ". " << comp->getName();
        if(comp->isActive()){
            cout << " [ACTIVE]";
        }
        cout << endl;
        it->next();
    }
    cout << "Total: " << count << " items" << endl;
}

// Helper: Show resource status
void showResources(FireDepartment* f, PoliceDepartment* p, MedicalDepartment* m) {
    cout << "Resources:" << endl;
    cout << "  Fire:   " << f->getNumTrucks() << " trucks (used: " << f->getAllocatedResources() << ")" << endl;
    cout << "  Police: " << p->getNumVehicles() << " vehicles (used: " << p->getAllocatedResources() << ")" << endl;
    cout << "  Medical:" << m->getNumAmbulances() << " ambulances (used: " << m->getAllocatedResources() << ")" << endl;
}

int main() {
    cout << "\n===== EMERGENCY RESPONSE SYSTEM TESTS =====\n" << endl;

    // ============================================================
    // TEST 1: BUILD COMPOSITE STRUCTURE
    // ============================================================
    cout << "TEST 1: Building Composite Structure" << endl;
    cout << "------------------------------------" << endl;

    FireDepartment* fireDept = new FireDepartment();
    PoliceDepartment* policeDept = new PoliceDepartment();
    MedicalDepartment* medicalDept = new MedicalDepartment();

    EmergencyTask* fireTask = new EmergencyTask("House Fire", fireDept, ResourceType::FireTruck);
    EmergencyTask* policeTask = new EmergencyTask("Bank Robbery", policeDept, ResourceType::PoliceCar);
    EmergencyTask* medicalTask = new EmergencyTask("Mass Casualty", medicalDept, ResourceType::Ambulance);
    EmergencyTask* medicalTask2 = new EmergencyTask("Heart Attack", medicalDept, ResourceType::Ambulance);

    fireDept->add(fireTask);
    policeDept->add(policeTask);
    medicalDept->add(medicalTask);
    medicalDept->add(medicalTask2);

    Composite* root = new Composite("Emergency System");
    root->add(fireDept);
    root->add(policeDept);
    root->add(medicalDept);

    cout << "Root: " << root->getName() << endl;
    cout << "Children: " << root->getChildren().size() << " departments" << endl;
    
    // Test add/remove
    EmergencyTask* extraTask = new EmergencyTask("Car Fire", fireDept, ResourceType::FireTruck);
    fireDept->add(extraTask);
    cout << "Added 'Car Fire' to Fire Dept (now " << fireDept->getChildren().size() << " tasks)" << endl;
    fireDept->remove(extraTask);
    cout << "Removed 'Car Fire' (now " << fireDept->getChildren().size() << " tasks)" << endl;
    delete extraTask;
    cout << "\nTEST 1: PASSED\n" << endl;

    // ============================================================
    // TEST 2: ITERATOR PATTERN
    // ============================================================
    cout << "TEST 2: Iterator Pattern" << endl;
    cout << "------------------------" << endl;
    cout << "Activating: House Fire, Mass Casualty" << endl;
    fireTask->executeResponse();
    medicalTask->executeResponse();

    CompleteDfsIterator dfsIt(root);
    printIterator(&dfsIt, "Complete DFS (visits ALL nodes)");

    ActiveTaskIterator activeIt(root);
    printIterator(&activeIt, "Active Tasks Only (snapshot)");

    cout << "\nTEST 2: PASSED\n" << endl;

    cout << "TEST 3: State Pattern" << endl;
    cout << "--------------------" << endl;

    FireDepartment* stateDept = new FireDepartment();
    EmergencyTask* stateTask = new EmergencyTask("Chemical Spill", stateDept, ResourceType::FireTruck);

    cout << "Task: " << stateTask->getName() << endl;
    cout << "  Initial State: " << stateTask->getStateName() << endl;

    // Test state transitions
    AlertState alert;
    alert.handleMobilization(stateTask);
    cout << "  After Mobilize: " << stateTask->getStateName() << endl;

    ResponseState response;
    response.handleWorkExecution(stateTask);
    cout << "  After Execute: " << stateTask->getStateName() << endl;

    RecoveryState recovery;
    recovery.handleRecovery(stateTask);
    cout << "  After Recovery: " << stateTask->getStateName() << endl;

    // Test invalid transition
    cout << "  Testing invalid transition (Mobilize from Recovery):" << endl;
    recovery.handleMobilization(stateTask);

    delete stateTask;
    delete stateDept;

    cout << "\nTEST 3: PASSED\n" << endl;

    // ============================================================
    // TEST 4: DECORATOR PATTERN
    // ============================================================
    cout << "TEST 4: Decorator Pattern" << endl;
    cout << "-------------------------" << endl;

    FireDepartment* decDept = new FireDepartment();
    EmergencyTask* baseTask = new EmergencyTask("High-Rise Fire", decDept, ResourceType::FireTruck);

    // Priority Decorator
    PriorityDecorator* priorityTask = new PriorityDecorator(baseTask, 3);
    cout << "Priority: " << priorityTask->getPriority() << endl;
    cout << "  Executing with priority 3: ";
    priorityTask->executeResponse();

    cout << "  Executing with priority 6 (invalid > 5): ";
    priorityTask->setPriority(6);
    priorityTask->executeResponse();

    // Safety Check Decorator
    SafetyCheckDecorator* safeTask = new SafetyCheckDecorator(priorityTask);
    cout << "\nSafety checks (all false): ";
    safeTask->executeResponse();

    cout << "  Setting safety conditions..." << endl;
    safeTask->setEquipmentReady(true);
    safeTask->setAreaSafe(true);
    safeTask->setPersonnelReady(true);
    cout << "  Safety checks (all true): ";
    safeTask->executeResponse();

    // Combined Decorators
    EmergencyTask* combinedBase = new EmergencyTask("Combined", decDept, ResourceType::FireTruck);
    PriorityDecorator* combinedPriority = new PriorityDecorator(combinedBase, 4);
    SafetyCheckDecorator* combinedSafe = new SafetyCheckDecorator(combinedPriority);
    
    cout << "\nCombined decorators (Safety + Priority):" << endl;
    combinedSafe->setEquipmentReady(true);
    combinedSafe->setAreaSafe(true);
    combinedSafe->setPersonnelReady(true);
    combinedSafe->executeResponse();

    delete safeTask;
    delete combinedSafe;
    delete decDept;

    cout << "\nTEST 4: PASSED\n" << endl;




    cout << "TEST 5: Resource Management" << endl;
    cout << "---------------------------" << endl;

    FireDepartment* resFire = new FireDepartment();
    PoliceDepartment* resPolice = new PoliceDepartment();
    MedicalDepartment* resMedical = new MedicalDepartment();

    showResources(resFire, resPolice, resMedical);

    EmergencyTask* resFireTask = new EmergencyTask("Wildfire", resFire, ResourceType::FireTruck);
    EmergencyTask* resPoliceTask = new EmergencyTask("Robbery", resPolice, ResourceType::PoliceCar);
    EmergencyTask* resMedicalTask = new EmergencyTask("Casualty", resMedical, ResourceType::Ambulance);

    cout << "\nAllocating resources..." << endl;
    resFireTask->executeResponse();  // Allocates 1
    resFireTask->increaseResources(ResourceType::FireTruck, 1);  // Allocates 1 more
    resPoliceTask->executeResponse();  // Allocates 5
    resMedicalTask->executeResponse();  // Allocates 1

    showResources(resFire, resPolice, resMedical);

    cout << "\nTask allocations:" << endl;
    cout << "  Fire: " << resFireTask->getAllocatedResources() << " trucks" << endl;
    cout << "  Police: " << resPoliceTask->getAllocatedResources() << " vehicles" << endl;
    cout << "  Medical: " << resMedicalTask->getAllocatedResources() << " ambulances" << endl;

    cout << "\nReleasing resources..." << endl;
    resFireTask->releaseResources(1);
    resMedicalTask->releaseResources(1);

    showResources(resFire, resPolice, resMedical);

    delete resFireTask;
    delete resPoliceTask;
    delete resMedicalTask;
    delete resFire;
    delete resPolice;
    delete resMedical;

    cout << "\nTEST 5: PASSED\n" << endl;



    
    cout << "TEST 6: Print Functionality" << endl;
    cout << "---------------------------" << endl;

    cout << "\nPrinting EmergencyTask:" << endl;
    fireTask->print();

    cout << "\nPrinting FireDepartment:" << endl;
    fireDept->print();

    cout << "\nPrinting Root Composite:" << endl;
    root->print();

    cout << "\nTEST 6: PASSED\n" << endl;
    delete root;  

    cout << "========================================" << endl;
    cout << "ALL TESTS PASSED SUCCESSFULLY!" << endl;
    cout << "========================================" << endl;

    return 0;
}